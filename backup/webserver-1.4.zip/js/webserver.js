/*jshint quotmark: double, multistr: true*/
/*global webserver: true*/
webserver = {

	favicon: "AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAA\
AAAAAAAAAAAAAAAAAAAAAAD/dYEBAAAAAP90eQf/c3Mm/3NzLv9zcy7/c3Mk/3NzBAAAAACubU4B\
AAAAAAAAAAAAAAAAAAAAAAAAAAD/c3MBAAAAAP9zc5D4c3D6/nNz//9zc///c3P//3Nz//9zc/v/\
c3N//wAAAD1kGwEAAAAAAAAAAAAAAAD/AAAA/3NzDv91gOY0ZBj//3N1/P5zc/7/c3P//3Nz//9z\
c/7+c3P7/3Nz/z9kHN7/rv8CFmEKAQAAAAD/c3MCAAAAAP1zcu34c3D1AF8A//dzb//6c3H//3Nz\
//9zc///c3P//nNy//9zc/8hYg/0C2AF3wAAAAALYAUBAAAAAP9zc5P4cnD/nGtG/wNfAf8TYAj/\
/3R3//5zc///c3P//3Nz//9zc///c3P/OmMa/wZfA/8AXwCDAAAAAP9zcwn/c3P/+nNx/XxpOP8F\
XwL/Al8B/xxiDf//dHr//3Nz//9zc///c3P//3Nz/5hrRP8AXgD8AF8A+wBfAAb/c3M+/3Nz/v90\
d/8aYQz/Al8B/wBfAP8AXgD//3N2//9zc///c3P//3Nz//91fv+Za0X/AF4A/gBfAP8AXwAl/nNz\
Uf9zdP01Yxj/CGAD/wBfAP8EXwL/YWcs//9zc///c3P//HNy//Jybf8AXgD/AF8A/wBfAP8AXwD/\
AF8ALv9zc1H/c3P90nBf/wBdAP8FXwL/AF8A//90dv/+c3L//3Nz//hycP/Cblf/AV8A/wFfAP8A\
XwD/AF8A/wBfAC7/c3NC/3Nz/v91ff9CZB3/eGg3//tzcf/7c3H//3Nz//9zc//6c3H/2HBh/wBe\
AP8AXgD/AF0A/wFfAP8AXwAo/3NzDv9zc//Mb1z9X2cr//dycP/+c3L//3Nz//9zc///c3P//3Nz\
//90d/96aTf/lWtD/+hxafwAXwD6JGIQBwAAAAD6c3GlF2EK//hzcP/Lb1z//3Nz//1zcv//c3P/\
/3Nz//9zc///dHn/O2Mb/yBiDv8DXwH/Al8AiwAAAABNZSICAAAAAABfAPYAXQD2DWAG/8NvWP/l\
cWf//3V9//5zcv//c3P/+nNx//92gf8PYAb1BmAD6AAAAAABXwABAAAAAACAAAAAXwAVAF8A9gJf\
Af8AXgD9AF4A/x1hDf/+c3L//HNy//90ef0ZYQz/Al8B7mFBAAEFXgABAAAAAAAAAAAAAAAAAIAA\
AAAAAAAAXwCcAF8A/wBfAP4AXwD9LGIT/f90e/7/c3b/dWg1kwAAAAABfwAAAAAAAAAAAAAAAAAA\
AAAAAAAAAAAAXwACAAAAAABfAAw0YhdBIGIOURZhClHYcGI+0HBeCQAAAAAOYAYCAAAAAAAAAAAA\
AAAA//8AAPAfAADgBwAAwAMAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAwAMAAOAH\
AADwDwAA//8AAA==",
	index: "<!DOCTYPE HTML>\n\
<html>\n\
<head>\n\
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n\
<title>FFOS WebServer</title>\n\
</head>\n\
<body>\n\
<h1>Welcome to Firefox OS WebServer 1.4</h1>\n\
</body>\n\
</html>\n",
	mimeTypes: {
		"css": "text/css",
		"gif": "image/gif",
		"htm": "text/html",
		"html": "text/html",
		"ico": "image/x-icon",
		"jpeg": "image/jpeg",
		"jpg": "image/jpeg",
		"js": "text/javascript",
		"json": "application/json",
		"less": "text/css",
		"mp3": "audio/mpeg",
		"mp4": "video/mpeg4",
		"ogg": "audio/ogg",
		"ogv": "video/ogg",
		"pdf": "application/pdf",
		"png": "image/png",
		"shtml": "text/html",
		"svg": "image/svg+xml",
		"txt": "text/plain",
		"webapp": "application/x-web-app-manifest+json",
		"webm": "video/webm",
		"xhtml": "text/html",
		"zip": "application/zip"
	},
	
	reasonPhrases: {
		"100": "Continue",
		"101": "Switching Protocols",
		"200": "OK",
		"201": "Created",
		"202": "Accepted",
		"203": "Non-Authoritative Information",
		"204": "No Content",
		"205": "Reset Content",
		"206": "Partial Content",
		"300": "Multiple Choices",
		"301": "Moved Permanently",
		"302": "Found",
		"303": "See Other",
		"304": "Not Modified",
		"305": "Use Proxy",
		"307": "Temporary Redirect",
		"400": "Bad Request",
		"401": "Unauthorized",
		"402": "Payment Required",
		"403": "Forbidden",
		"404": "Not Found",
		"405": "Method Not Allowed",
		"406": "Not Acceptable",
		"407": "Proxy Authentication Required",
		"408": "Request Time-out",
		"409": "Conflict",
		"410": "Gone",
		"411": "Length Required",
		"412": "Precondition Failed",
		"413": "Request Entity Too Large",
		"414": "Request-URI Too Large",
		"415": "Unsupported Media Type",
		"416": "Requested range not satisfiable",
		"417": "Expectation Failed",
		"500": "Internal Server Error",
		"501": "Not Implemented",
		"502": "Bad Gateway",
		"503": "Service Unavailable",
		"504": "Gateway Time-out",
		"505": "HTTP Version not supported"
	}
	
};
