// TOUCH
var MARK_UNREAD_TOUCH_DELAY = 600;
var TOUCH_OFFSET            = 5;

var ALARM_ACTION_RELOAD = "reload";

var AUTOREFRESH_STARTUP = "startup";

var MIME_TYPES = {
    'IMAGE' : ['image/jpeg', 'image/png'],
    'AUDIO' : ['audio/mpeg', 'audio/ogg', 'audio/wav', 'audio/webm'],
    'VIDEO' : ['video/mp4', 'video/ogg', 'video/webm']
};
