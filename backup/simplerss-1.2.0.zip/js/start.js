Backbone.pubSub = _.extend({}, Backbone.Events);

navigator.mozL10n.ready(function() {
    // grab l10n object
    translate = navigator.mozL10n.get;

    // Set momentjs lang
    moment.lang(navigator.mozL10n.language.code);

    // Create feed backbone objects
    feedList     = new FeedList();
    listFeedView = new ListFeedView();
    addFeedView  = new AddFeedView();
    editFeedView = new EditFeedView();

    // Create item backbone objects
    listItemView = new ListItemView();

    // Create timeline backbone objects
    timelineView = new TimelineView();

    // Init DB and load feeds from DB
    database.initialize();
});

