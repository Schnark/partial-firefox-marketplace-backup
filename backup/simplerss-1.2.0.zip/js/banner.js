// Set up the banner to disappear after 4 seconds
function scheduleBanner() {
    window.setTimeout(function() {
        document.getElementById("banner").classList.remove('show-banner');

        setTimeout(function() {
            document.getElementById("banner").hidden = true;
            document.getElementById("banner-content").innerHTML = '';
        }, 300);

    }, 4000);
}

// Display the banner
function showBanner(content, param, lock) {
    content = translate(content);

    if (param) {
        content += param;
    }

    document.getElementById("banner-content").innerHTML = content;
    document.getElementById("banner").hidden = false;

    setTimeout(function() {
        document.getElementById("banner").classList.add('show-banner');
    }, 1);

    // Do not hide banner after timing if locked
    if (lock) {
        return;
    }

    scheduleBanner();
}
